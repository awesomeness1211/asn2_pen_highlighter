# 234504H_TanQianPeng > 2025-07-09 10:45am
https://universe.roboflow.com/myworkspace101/234504h_tanqianpeng

Provided by a Roboflow user
License: CC BY 4.0

